"""Shared navigation for public SpookyQubits pages outside the games."""

from html import escape


PUBLIC_HOME = "https://spookyqubits.com/"

GHOST = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><path d="M18.5 18C19.5 10.5 25 5.5 31.5 5.5C39 5.5 44.5 11.5 45 19C45.2 22.5 45.5 25 47 26C50 27.5 55.5 25.5 58.5 27.5C62 30 59.5 35.5 55 36C51.5 36.5 48.5 36.5 46.5 38.5C43.5 45.5 36 51.5 26 53.5C19 55 12 55.5 8 54C5.5 53 7.5 50.5 10.5 48.5C12.5 47 13 45.5 13 44C14 40.5 14.3 37 14 34C11 34.2 6.5 33.5 4.2 30.5C2 27.5 3.5 23 8 22.5C12 22 16 21 18.5 18Z" fill="#fff8f4" stroke="#d3061c" stroke-width="2.5" stroke-linejoin="round"/><ellipse cx="29" cy="17.5" rx="2.6" ry="3.6" fill="#242622"/><ellipse cx="37.5" cy="19.5" rx="2.3" ry="3.3" fill="#242622"/><path d="M30.2 24.6Q33.4 25.8 36.6 24.9Q36 29.2 33 29Q30.6 28.6 30.2 24.6Z" fill="#242622"/></svg>'''

HEADER = '''
  <header class="sq-site-header">
    <a class="sq-brand" href="{home}" aria-label="SpookyQubits home">{ghost}<span>Spooky<span class="sq-brand-red">Qubits</span></span></a>
    <nav aria-label="Main navigation">
      <a href="{section_home}#collections">Collections</a>
      <a href="{page_root}game-catalog.html"{catalog_current}>Game Catalog</a>
      <a href="{page_root}concepts.html"{concepts_current}>Concept Map</a>
      <a href="{page_root}educators.html"{educators_current}>For educators</a>
      <span class="sq-social-links" aria-label="Connect"><a href="https://www.youtube.com/@SpookyQubits" aria-label="YouTube" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31.3 31.3 0 0 0 0 12c0 1.9.2 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1c.3-1.9.5-3.9.5-5.8s-.2-3.9-.5-5.8ZM9.6 15.6V8.4l6.2 3.6-6.2 3.6Z"/></svg></a><a href="https://x.com/SpookyQubits" aria-label="X" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 1.2h3.7l-8 9.2L24 22.8h-7.4l-5.8-7.6-6.7 7.6H.4l8.6-9.9L0 1.2h7.6l5.2 6.9 6.1-6.9Zm-1.3 19.4h2L6.5 3.2H4.3l13.3 17.4Z"/></svg></a><a href="https://github.com/spookyqubits" aria-label="GitHub" title="GitHub" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 .75a11.25 11.25 0 0 0-3.56 21.92c.56.1.77-.24.77-.54v-2.1c-3.13.68-3.79-1.33-3.79-1.33-.51-1.3-1.25-1.64-1.25-1.64-1.02-.7.08-.69.08-.69 1.13.08 1.73 1.16 1.73 1.16 1 1.72 2.63 1.22 3.27.93.1-.72.39-1.22.7-1.5-2.5-.28-5.13-1.25-5.13-5.56 0-1.23.44-2.24 1.16-3.03-.12-.28-.5-1.43.11-2.98 0 0 .95-.3 3.1 1.16a10.8 10.8 0 0 1 5.64 0c2.15-1.46 3.09-1.16 3.09-1.16.62 1.55.23 2.7.11 2.98.72.79 1.16 1.8 1.16 3.03 0 4.32-2.64 5.27-5.15 5.55.4.35.76 1.03.76 2.08v3.1c0 .3.21.65.78.54A11.25 11.25 0 0 0 12 .75Z"/></svg></a><a href="mailto:spookyqubits@gmail.com" aria-label="Contact us by email" title="Contact us"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 18V6l9 7 9-7v12" fill="none" stroke="#ea4335" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 9v9" fill="none" stroke="#4285f4" stroke-width="2.5" stroke-linecap="round"/><path d="M21 9v9" fill="none" stroke="#34a853" stroke-width="2.5" stroke-linecap="round"/><path d="M21 6v3" fill="none" stroke="#fbbc04" stroke-width="2.5" stroke-linecap="round"/></svg></a></span>
      <a class="sq-nav-cta" href="{section_home}#collections">Let’s play <span aria-hidden="true">↗</span></a>
    </nav>
  </header>
'''

STYLE = """
.sq-site-header {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: min(1220px, calc(100% - 96px));
  max-width: none;
  min-height: 102px;
  margin: 0 auto;
  padding: 0;
  border-bottom: 1px solid #dfded6;
  color: #242622;
  font: 650 14px/1.25 "Avenir Next", Avenir, "Segoe UI", system-ui, sans-serif;
}
.sq-site-header nav {
  display: flex;
  align-items: center;
  gap: 32px;
  margin: 0;
}
.sq-site-header a {
  box-sizing: border-box;
  display: inline-flex;
  align-items: center;
  min-height: 44px;
  padding: 0;
  color: inherit;
  text-decoration: none;
  white-space: nowrap;
}
.sq-site-header a:hover { color: #cc0000; }
.sq-site-header a:focus-visible { outline: 3px solid #1363c4; outline-offset: 5px; }
.sq-site-header .sq-brand { gap: 9px; font-size: 23px; font-weight: 850; letter-spacing: -1.2px; }
.sq-site-header .sq-brand svg { display: block; width: 40px; height: 40px; }
.sq-site-header .sq-brand-red { color: #cc0000; }
.sq-site-header .sq-social-links { display: inline-flex; align-items: center; gap: 4px; }
.sq-site-header .sq-social-links a {
  justify-content: center;
  width: 40px;
  min-height: 40px;
  border: 1px solid #dfded6;
  border-radius: 50%;
}
.sq-site-header .sq-social-links a:hover { border-color: #cc0000; background: #fffefa; }
.sq-site-header .sq-social-links svg { display: block; width: 19px; height: 19px; fill: currentColor; }
.sq-site-header .sq-nav-cta {
  gap: 22px;
  padding: 10px 19px;
  border: 1px solid #242622;
  border-radius: 999px;
}
.sq-site-header .sq-nav-cta:hover { background: #242622; color: white; }
@media (max-width: 1120px) {
  .sq-site-header { flex-wrap: wrap; gap: 8px; padding-block: 12px; }
  .sq-site-header nav { flex-wrap: wrap; justify-content: flex-end; gap: 0 14px; margin-left: auto; }
}
@media (max-width: 800px) {
  .sq-site-header { width: calc(100% - 40px); min-height: 78px; }
  .sq-site-header .sq-brand { font-size: 20px; }
}
@media (max-width: 560px) {
  .sq-site-header { width: calc(100% - 36px); min-height: 73px; }
  .sq-site-header nav { justify-content: flex-start; gap: 0 10px; margin-left: 0; font-size: 12px; }
  .sq-site-header .sq-brand { gap: 6px; font-size: 19px; }
  .sq-site-header .sq-brand svg { width: 33px; height: 33px; }
  .sq-site-header .sq-social-links { gap: 2px; }
  .sq-site-header .sq-social-links a { width: 36px; min-height: 36px; }
  .sq-site-header .sq-social-links svg { width: 17px; height: 17px; }
  .sq-site-header .sq-nav-cta { padding: 8px 10px; gap: 6px; }
}
.sq-document-page { margin: 0; background: #faf7f1; }
@media print {
  .sq-site-header { display: none !important; }
  .sq-document-page { background: white; }
}
"""


def with_header(page, home=PUBLIC_HOME, *, current=None):
    """Fill a page that opts in to the shared header at build time."""
    assert page.count('{{SITE_HEADER}}') == 1 and '</head>' in page
    relative_home = home.endswith('index.html')
    page_root = home.removesuffix('index.html') if relative_home else home
    ghost = GHOST.replace('<svg ', '<svg aria-hidden="true" ', 1)
    header = HEADER.format(
        home=home,
        section_home='' if current == 'home' else home,
        page_root=page_root,
        ghost=ghost,
        catalog_current=' aria-current="page"' if current == 'catalog' else '',
        concepts_current=' aria-current="page"' if current == 'concepts' else '',
        educators_current=' aria-current="page"' if current == 'educators' else '',
    ).strip()
    return page.replace('{{SITE_HEADER}}', header).replace('</head>', '<style>' + STYLE + '</style>\n</head>', 1)


def document_page(page, home=PUBLIC_HOME):
    """Keep the existing guide or printable centered below the site navigation."""
    if '<body>' not in page:
        # The older Catch the Photon facilitator guide has an implied body.
        page = page.replace('</style>', '</style></head><body>', 1)
        page = page.replace('</html>', '</body></html>', 1)
    page = page.replace('body{', '.sq-document{')
    return with_header(page.replace('<body>', '<body class="sq-document-page">{{SITE_HEADER}}<div class="sq-document">', 1)
                       .replace('</body>', '</div></body>', 1), home)


def not_found_page(title, heading, return_url, return_text):
    return with_header(f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page not found · {escape(title)}</title>
<style>body{{margin:0;font-family:system-ui,sans-serif;background:#faf7f1;color:#242622}}
main{{max-width:720px;margin:0 auto;padding:clamp(24px,6vw,72px) 24px}}main a{{color:#a32132}}</style></head>
<body>{{{{SITE_HEADER}}}}<main><h1>{escape(heading)}</h1><p><a href="{escape(return_url)}">{escape(return_text)}</a></p></main></body></html>
''')
